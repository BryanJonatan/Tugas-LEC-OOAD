package singleton;

import java.util.ArrayList;

import builder.Builder;

public class Singleton {
    private static Singleton instance;
    private ArrayList<Builder> todoList;

    // Private constructor
    private Singleton() {
        todoList = new ArrayList<>();
    }

    // Public method to get the Singleton instance
    public static synchronized Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    // Add a todo item
    public void addTodoItem(Builder item) {
        todoList.add(item);
    }

    // Remove a todo item
    public void removeTodoItem(int index) {
        if (index >= 0 && index < todoList.size()) {
            todoList.remove(index);
        }
    }

    // Get all todo items
    public ArrayList<Builder> getTodoList() {
        return todoList;
    }

    // Mark a todo item as completed
    public void completeTodoItem(int index) {
        if (index >= 0 && index < todoList.size()) {
            todoList.get(index).complete();
        }
    }
}

