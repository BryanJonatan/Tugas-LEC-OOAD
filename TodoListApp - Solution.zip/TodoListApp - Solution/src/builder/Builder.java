package builder;

public class Builder {
    private String name;
    private boolean isCompleted;

    private Builder(TodoItemBuilder builder) {
        this.name = builder.name;
        this.isCompleted = builder.isCompleted;
    }

    public String getName() {
        return name;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void complete() {
        this.isCompleted = true;
    }

    @Override
    public String toString() {
        return name + (isCompleted ? " (Completed)" : " (Pending)");
    }

    public static class TodoItemBuilder {
        private String name;
        private boolean isCompleted;

        public TodoItemBuilder setName(String name) {
            this.name = name;
            return this;
        }

        public TodoItemBuilder setCompleted(boolean isCompleted) {
            this.isCompleted = isCompleted;
            return this;
        }

        public Builder build() {
            return new Builder(this);
        }
    }
}
