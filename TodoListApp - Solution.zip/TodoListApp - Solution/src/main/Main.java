package main;

import java.util.Scanner;

import builder.Builder;
import singleton.Singleton;

public class Main {
    public static void RunTodoListApp(String[] args) {
        Singleton todoListManager = Singleton.getInstance();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("==== Todo List ====");
            // Print all Todo Items
            for (int i = 0; i < todoListManager.getTodoList().size(); i++) {
                System.out.println((i + 1) + ". " + todoListManager.getTodoList().get(i));
            }
            System.out.println("====================");
            System.out.println("1. Add item");
            System.out.println("2. Remove item");
            System.out.println("3. Mark item as completed");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character
            
            if (choice == 1) {
                System.out.print("Enter item to add: ");
                String itemName = scanner.nextLine();
                
                // Create a TodoItem using the Builder
                Builder newItem = new Builder.TodoItemBuilder()
                    .setName(itemName)
                    .setCompleted(false)
                    .build();
                
                todoListManager.addTodoItem(newItem);
                System.out.println("Item added!");
            } else if (choice == 2) {
                System.out.print("Enter item number to remove: ");
                int itemNum = scanner.nextInt();
                scanner.nextLine(); // consume the newline character
                if (itemNum > 0 && itemNum <= todoListManager.getTodoList().size()) {
                    todoListManager.removeTodoItem(itemNum - 1);
                    System.out.println("Item removed!");
                } else {
                    System.out.println("Invalid item number.");
                }
            } else if (choice == 3) {
                System.out.print("Enter item number to mark as completed: ");
                int itemNum = scanner.nextInt();
                scanner.nextLine(); // consume the newline character
                if (itemNum > 0 && itemNum <= todoListManager.getTodoList().size()) {
                    todoListManager.completeTodoItem(itemNum - 1);
                    System.out.println("Item marked as completed!");
                } else {
                    System.out.println("Invalid item number.");
                }
            } else if (choice == 4) {
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
        
        System.out.println("Exiting Todo List App.");
    }

    public static void main(String[] args) {
        RunTodoListApp(args);
    }
}

