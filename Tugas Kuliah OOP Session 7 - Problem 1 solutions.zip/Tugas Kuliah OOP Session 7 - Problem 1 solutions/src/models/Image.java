package models;

public class Image extends Work_type{

	  private String type;

	    public Image(String workTitle, String level, String id, String type) {
	        super(workTitle, level, id);
	        this.type = type;
	    }

	    public String getType() {
	        return type;
	    }

}
