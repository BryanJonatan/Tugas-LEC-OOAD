package models;

public abstract class Work_type {
	 private String workTitle;
	    private String level;
	    private String id;

	    public Work_type(String workTitle, String level, String id) {
	        this.workTitle = workTitle;
	        this.level = level;
	        this.id = id;
	    }

	    public String getWorkTitle() {
	        return workTitle;
	    }

	    public String getLevel() {
	        return level;
	    }

	    public String getId() {
	        return id;
	    }
	

}
