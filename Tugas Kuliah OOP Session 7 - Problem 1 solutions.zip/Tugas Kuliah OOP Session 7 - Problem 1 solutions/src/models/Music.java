package models;

public class Music extends Work_type{

	 private String genre;

	    public Music(String workTitle, String level, String id, String genre) {
	        super(workTitle, level, id);
	        this.genre = genre;
	    }

	    public String getGenre() {
	        return genre;
	    }

}
