package models;

public class Video extends Work_type{

	 private int duration;

	    public Video(String workTitle, String level, String id, int duration) {
	        super(workTitle, level, id);
	        this.duration = duration;
	    }

	    public int getDuration() {
	        return duration;
	    }

}
