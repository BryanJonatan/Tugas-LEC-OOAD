package factory;

import models.Image;

import models.Music;
import models.Video;
import models.Work_type;

public class WorkTypeFactory {
	 public Work_type createWork(String type, String title, 
			 String level, String id, Object extra) {
		 
	        switch (type.toLowerCase()) {
	            case "music":
	                return new Music(title, level, id, (String) extra);
	            case "video":
	                return new Video(title, level, id, (int) extra);
	            case "image":
	                return new Image(title, level, id, (String) extra);
	            default:
	                throw new IllegalArgumentException("Invalid work type: " + type);
	        }
	    }

}
