package adapter;

import models.Work_type;

public class WorkTypeAdapter {
	  private Work_type workType;

	    public WorkTypeAdapter(Work_type workType) {
	        this.workType = workType;
	    }

	    public String getFormattedDetails() {
	        return String.format("Title: %s, Level: %s, ID: %s", 
	        		workType.getWorkTitle(), workType.getLevel(), workType.getId());
	    }

}
