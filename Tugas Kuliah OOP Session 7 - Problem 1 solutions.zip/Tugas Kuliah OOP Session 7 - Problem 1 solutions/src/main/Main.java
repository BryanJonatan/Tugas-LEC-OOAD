package main;
import java.util.Scanner;
import java.util.stream.Collectors;

import factory.WorkTypeFactory;
import singleton.Creator;
import models.Work_type;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;
import java.util.*;
import adapter.WorkTypeAdapter;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final WorkTypeFactory factory = new WorkTypeFactory();
    private static final ArrayList<Work_type> works = new ArrayList<>();
    private static final Map<String, List<String>> supportedCreators = new HashMap<>();

    public static void main(String[] args) {
        Creator manager = Creator.getInstance();
        manager.manageCreators();
        
        boolean running = true;
        while (running) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Insert new work");
            System.out.println("2. Support a creator");
            System.out.println("3. View all subscribers");
            System.out.println("4. View your work");
            System.out.println("5. View accessible work");
            System.out.println("6. Log out");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    insertNewWork();
                    break;
                case 2:
                    supportCreator();
                    break;
                case 3:
                    viewAllSubscribers();
                    break;
                case 4:
                    viewYourWork();
                    break;
                case 5:
                    viewAccessibleWork();
                    break;
                case 6:
                    running = false;
                    System.out.println("Logging out...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void insertNewWork() {
        System.out.print("Enter work type (music/video/image): ");
        String type = scanner.nextLine();

        Object extra = null;
        if (type.equalsIgnoreCase("music")) {
            System.out.print("Enter genre: ");
            extra = scanner.nextLine();
        } else if (type.equalsIgnoreCase("video")) {
            System.out.print("Enter duration: ");
            extra = scanner.nextInt();
            scanner.nextLine();
        } else if (type.equalsIgnoreCase("image")) {
            System.out.print("Enter image type (JPEG/PNG): ");
            extra = scanner.nextLine();
        }

        System.out.print("Enter title: ");
        String title = scanner.nextLine();

        System.out.print("Enter level (bronze/silver/gold): ");
        String level = scanner.nextLine();

        String id = String.format("%09d", new Random().nextInt(1_000_000_000));

        Work_type work = factory.createWork(type, title, level, id, extra);
        works.add(work);
        System.out.println("Work added successfully!");
    }

    private static void supportCreator() {
        System.out.println("Available creators: User1, User2, User3"); // Example creators
        System.out.print("Enter creator's username to support: ");
        String username = scanner.nextLine();

        System.out.print("Enter subscription level (bronze/silver/gold): ");
        String level = scanner.nextLine();

        supportedCreators.computeIfAbsent(username, k -> new ArrayList<>()).add(level);
        System.out.println("You are now supporting " + username + " at " + level + " level.");
    }

    private static void viewAllSubscribers() {
        if (supportedCreators.isEmpty()) {
            System.out.println("No subscriber");
        } else {
            System.out.println("Subscribers by level:");
            supportedCreators.forEach((creator, levels) -> {
                System.out.println(creator + ": " + String.join(", ", levels));
            });
        }
    }

    private static void viewYourWork() {
        if (works.isEmpty()) {
            System.out.println("No works uploaded yet");
        } else {
            System.out.println("Your works:");
            works.stream().collect(Collectors.groupingBy(w -> w.getClass().getSimpleName()))
                 .forEach((type, workList) -> {
                     System.out.println(type + ":");
                     workList.forEach(work -> {
                         WorkTypeAdapter adapter = new WorkTypeAdapter(work);
                         System.out.println(adapter.getFormattedDetails());
                     });
                 });
        }
    }

    private static void viewAccessibleWork() {
        System.out.println("This feature is not fully implemented yet."); // Placeholder for grouping logic
    }

}
