package singleton;

public class Creator {

	private static Creator instance;

    private Creator() {
        
    }

    public static Creator getInstance() {
        if (instance == null) {
            instance = new Creator();
        }
        return instance;
    }

    public void manageCreators() {
        System.out.println("Managing creators...");
    }

}
