package Session7;

public class video extends work_type{
	private Integer duration;

	public video(String work_title, String level, String iD) {
		super(work_title, level, iD);
		// TODO Auto-generated constructor stub
	}

	public video(String work_title, String level, String iD, Integer duration) {
		super(work_title, level, iD);
		this.duration = duration;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	

}
