package Session7;

public class work_type {
	private String work_title;
	private String level;
	private String ID;
	
	public work_type(String work_title, String level, String iD) {
		super();
		this.work_title = work_title;
		this.level = level;
		ID = iD;
	}

	public String getWork_title() {
		return work_title;
	}

	public void setWork_title(String work_title) {
		this.work_title = work_title;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}
	
}
