package Session7;

public class image extends work_type{
	private String type;

	public image(String work_title, String level, String iD) {
		super(work_title, level, iD);
		// TODO Auto-generated constructor stub
	}

	public image(String work_title, String level, String iD, String type) {
		super(work_title, level, iD);
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
