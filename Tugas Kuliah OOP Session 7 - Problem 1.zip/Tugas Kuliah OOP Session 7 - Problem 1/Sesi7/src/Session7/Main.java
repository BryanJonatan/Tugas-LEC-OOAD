package Session7;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
	Integer n, a;
	String username, type;
	String CreatorUsername, levels;
	Scanner scan = new Scanner(System.in);
	ArrayList<menu> rlist = new ArrayList<>();
	ArrayList<music> musics = new ArrayList<>();
	ArrayList<video> videos = new ArrayList<>();
	ArrayList<image> images = new ArrayList<>();
	ArrayList<creator> creators = new ArrayList<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}
	
	public void Insert() {
		System.out.print("Insert Username :");
		username = scan.nextLine();
		rlist.add(new menu(username));
	}
	
	boolean avaiable = false;
	
	public void new_work() {
		do {
			String genre_name, image_type, title, level;
			Integer video_duration;
			Random random = new Random();
			System.out.printf("Hello %s\n", username);
			System.out.print("Please Insert your work type: ");
			type = scan.nextLine();
			if(type.equals("music")) {
				System.out.print("Please Insert Genre Name: ");
				genre_name = scan.nextLine();
				System.out.print("Please Insert Title:");
				title = scan.nextLine();
				do {
					System.out.print("Please Insert Level [bronze || silver || gold]: ");
					level = scan.nextLine();
				}while(!level.equals("bronze") && !level.equals("silver") && !level.equals("gold"));
				String ID = "";
				for(int i = 0 ; i < 9 ; i++) {
					Integer randomDigit  = random.nextInt(10);
					ID += randomDigit;
				}
				musics.add(new music(title, level, ID, genre_name));
			}else if(type.equals("video")) {
				System.out.print("Please Insert Video Duration: ");
				video_duration = scan.nextInt();
				System.out.print("Please Insert Title:");
				title = scan.nextLine();
				do {
					System.out.print("Please Insert Level [bronze || silver || gold]: ");
					level = scan.nextLine();
				}while(!level.equals("bronze") && !level.equals("silver") && !level.equals("gold"));
				scan.nextLine();
				String ID = "";
				for(int i = 0 ; i < 9 ; i++) {
					Integer randomDigit  = random.nextInt(10);
					ID += randomDigit;
				}
				videos.add(new video(title, level, ID, video_duration));
			}else if(type.equals("image")){
				do {
					System.out.print("Please Insert Image Type [JPEG || PNG]: ");
					image_type = scan.nextLine();
				}while(!image_type.equals("JPEG") && !image_type.equals("PNG"));
				System.out.print("Please Insert Title:");
				title = scan.nextLine();
				do {
					System.out.print("Please Insert Level [bronze || silver || gold]: ");
					level = scan.nextLine();
				}while(!level.equals("bronze") && !level.equals("silver") && !level.equals("gold"));
				scan.nextLine();
				String ID = "";
				for(int i = 0 ; i < 9 ; i++) {
					Integer randomDigit  = random.nextInt(10);
					ID += randomDigit;
				}
				images.add(new image(title, level, ID, image_type));
			}
		}while(!type.equals("music") && !type.equals("video") && !type.equals("image"));
		
	}
	
	public boolean isSubscribed(creator user) {
        for (creator c : creators) {
            if (c.getName().equals(user.getName())) {
                return true;
            }
        }
        return false;
    }

    public menu findUsername(String find) {
        for (menu user : rlist) {
            if (user.getUser().equals(find)) {
                return user;
            }
        }
        return null;
    }
    
    public creator findCreator(String find) {
        for (creator creator : creators) {
            if (creator.getName().equals(find)) {
                return creator;
            }
        }
        return null;
    }
    
    creator currentUser;
    public void Support() {
        boolean subscribed = false;
        do {
            System.out.println("Creators you haven't subscribed to yet: ");
            int i = 0;
            for (creator creator : creators) {
                if (!isSubscribed(currentUser)) {
                    System.out.printf("%d. %s\n", i + 1, creator.getName());
                }
            }
            System.out.print("Enter a creator name to subscribe: ");
            CreatorUsername = scan.nextLine();
            if (CreatorUsername.equalsIgnoreCase("exit")) {
                break;
            } else {
                creator selectedCreator = findCreator(CreatorUsername);
                if (selectedCreator != null) {
                    subscribed = true;
                } else {
                    System.out.println("Invalid creator name. Please try again.");
                }
            }
        } while (!subscribed);
        do {
			System.out.print("Please Insert Level [bronze || silver || gold]: ");
			levels = scan.nextLine();
		}while(!levels.equals("bronze") && !levels.equals("silver") && !levels.equals("gold"));
        
        creators.add(new creator(new menu(CreatorUsername), new Subscriber(levels)));
    }
    
    ArrayList<creator> bronzeSubscribers = new ArrayList<>();
    ArrayList<creator> silverSubscribers = new ArrayList<>();
    ArrayList<creator> goldSubscribers = new ArrayList<>();
    
    public void view_subscriber() {
    	
    	for (creator creator2 : creators) {
            if (isSubscribed(currentUser)) {
                Subscriber subscriber = creator2.getSubscriber();
                if (subscriber.getLevel().equalsIgnoreCase("bronze")) {
                    bronzeSubscribers.add(creator2);
                } else if (subscriber.getLevel().equalsIgnoreCase("silver")) {
                    silverSubscribers.add(creator2);
                } else if (subscriber.getLevel().equalsIgnoreCase("gold")) {
                    goldSubscribers.add(creator2);
                }
            }
        }
    	
    	if (bronzeSubscribers.isEmpty() && silverSubscribers.isEmpty() && goldSubscribers.isEmpty()) {
            System.out.println("No subscribers.");
        } else {
            if (!bronzeSubscribers.isEmpty()) {
                System.out.println("Bronze Subscribers:");
                for (creator subscriber : bronzeSubscribers) {
                    System.out.println(subscriber.getName());
                }
            }

            if (!silverSubscribers.isEmpty()) {
                System.out.println("Silver Subscribers:");
                for (creator subscriber : silverSubscribers) {
                    System.out.println(subscriber.getName());
                }
            }

            if (!goldSubscribers.isEmpty()) {
                System.out.println("Gold Subscribers:");
                for (creator subscriber : goldSubscribers) {
                    System.out.println(subscriber.getName());
                }
            }
        }
    }
	
    public void view_work() {
    	if(musics.isEmpty() && videos.isEmpty() && images.isEmpty()) {
    		System.out.println("No Subscriber");
    	}else if(!musics.isEmpty()){
    		for(int i = 0 ; i < musics.size() ; i++) {
			System.out.printf("|	%d.	|	%s 	|	%s 	|	%s 	|	%s	|\n", i+1, musics.get(i).getGenre(),
					musics.get(i).getWork_title(), musics.get(i).getLevel(),musics.get(i).getID() );
    		}
    	}else if(!videos.isEmpty()) {
    		for(int i = 0 ; i < videos.size() ; i++) {
    			System.out.printf("|	%d.	|	%d 	|	%s 	|	%s 	|	%s	|\n", i+1, videos.get(i).getDuration(),
    					videos.get(i).getWork_title(), videos.get(i).getLevel(),videos.get(i).getID() );
        		}
    	}else if(!images.isEmpty()) {
    		for(int i = 0 ; i < images.size() ; i++) {
    			System.out.printf("|	%d.	|	%s 	|	%s 	|	%s 	|	%s	|\n", i+1, images.get(i).getType(),
    					images.get(i).getWork_title(), images.get(i).getLevel(), images.get(i).getID() );
        		}
    	}
    }
    
    public void view_accessible() {
    	if (creators.isEmpty()) {
            System.out.println("No works you can see.");
            return;
        }

        System.out.println("Accessible works:");

        for (creator creator : creators) {
           
            if (isSubscribed(creator)) {
                Subscriber subscriber = creator.getSubscriber();
                String level = subscriber.getLevel();

                System.out.println("Subscription Level: " + level);

                if (level.equalsIgnoreCase("bronze")) {

                    for (music music : musics) {
                        if (music.getLevel().equalsIgnoreCase("bronze")) {
                            System.out.println("Music: " + music.getWork_title());
                        }
                    }
                    for (video video : videos) {
                        if (video.getLevel().equalsIgnoreCase("bronze")) {
                            System.out.println("Video: " + video.getWork_title());
                        }
                    }
                    for (image image : images) {
                        if (image.getLevel().equalsIgnoreCase("bronze")) {
                            System.out.println("Image: " + image.getWork_title());
                        }
                    }
                } else if (level.equalsIgnoreCase("silver")) {

                    for (music music : musics) {
                        if (music.getLevel().equalsIgnoreCase("silver")) {
                            System.out.println("Music: " + music.getWork_title());
                        }
                    }
                    for (video video : videos) {
                        if (video.getLevel().equalsIgnoreCase("silver")) {
                            System.out.println("Video: " + video.getWork_title());
                        }
                    }
                    for (image image : images) {
                        if (image.getLevel().equalsIgnoreCase("silver")) {
                            System.out.println("Image: " + image.getWork_title());
                        }
                    }
                } else if (level.equalsIgnoreCase("gold")) {
                
                    for (music music : musics) {
                        if (music.getLevel().equalsIgnoreCase("gold")) {
                            System.out.println("Music: " + music.getWork_title());
                        }
                    }
                    for (video video : videos) {
                        if (video.getLevel().equalsIgnoreCase("gold")) {
                            System.out.println("Video: " + video.getWork_title());
                        }
                    }
                    for (image image : images) {
                        if (image.getLevel().equalsIgnoreCase("gold")) {
                            System.out.println("Image: " + image.getWork_title());
                        }
                    }
                }
            }
        }
    	
    }
    
	public void User_menu() {
		do {
		System.out.println("1. Insert new work");
		System.out.println("2. Support a creator");
		System.out.println("3. View all subscriber");
		System.out.println("4. View your work");
		System.out.println("5. View accessible work");
		System.out.println("6. Log out");
		a = scan.nextInt();
		scan.nextLine();
		if(a == 1) {
			new_work();
		}else if(a == 2) {
			Support();
		}else if(a == 3) {
			view_subscriber();
		}else if(a == 4) {
			view_work();
		}else if(a == 5) {
			view_accessible();
		}
		}while(a != 6);
		new Main();
	}
	
	
	public void Login() {
		if(rlist.size() == 0) {
			System.out.println("Empty!");
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
		}else {
			for(int i = 0 ; i < rlist.size() ; i++) {
				System.out.printf("%d. %s\n", i+1, rlist.get(i).getUser());
			}
			do {
				
				System.out.print("Please Enter Your Username: ");
				username = scan.nextLine();
				for(menu menu : rlist) {
					if(menu.getUser().equals(username)) {
						avaiable = true;
						break;
					}
				}
			}while(!avaiable);
			User_menu();
		}
		
	}
	
	public Main(){
		do {
			System.out.println("1. Insert new patreon user");
			System.out.println("2. Login");
			System.out.println("3. Exit");
			n = scan.nextInt();
			scan.nextLine();
			
			switch(n) {
			case 1:
				Insert();
				break;
			case 2:
				Login();
				break;
			}
		}while(n!=3);
	}
}
