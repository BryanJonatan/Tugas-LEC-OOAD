package Session7;

public class creator {
	private menu name;
	private Subscriber subscriber;
	
	public creator(menu name, Subscriber subscriber) {
		super();
		this.name = name;
		this.subscriber = subscriber;
	}

	public menu getName() {
		return name;
	}

	public void setName(menu name) {
		this.name = name;
	}

	public Subscriber getSubscriber() {
		return subscriber;
	}

	public void setSubscriber(Subscriber subscriber) {
		this.subscriber = subscriber;
	}
	
	
	
}
