package Session7;

public class Subscriber{
	private String level;
	
	public Subscriber(String level) {
		super();
		this.level = level;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
}
