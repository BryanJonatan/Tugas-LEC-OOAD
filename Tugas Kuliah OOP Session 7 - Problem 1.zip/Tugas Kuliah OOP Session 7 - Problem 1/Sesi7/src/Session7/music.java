package Session7;

public class music extends work_type{
	private String genre;

	public music(String work_title, String level, String iD) {
		super(work_title, level, iD);
		// TODO Auto-generated constructor stub
	}

	public music(String work_title, String level, String iD, String genre) {
		super(work_title, level, iD);
		this.genre = genre;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	
}
