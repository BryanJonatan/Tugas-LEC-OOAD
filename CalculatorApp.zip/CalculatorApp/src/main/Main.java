package main;

import java.util.Scanner;

import command.Operation;
import factory.Factory;

public class Main {
    public static void RunCalculator(String[] args) {
        Scanner input = new Scanner(System.in);
        double num1, num2, result;
        char operator;
        
        System.out.print("Enter the first number: ");
        num1 = input.nextDouble();
        
        System.out.print("Enter the second number: ");
        num2 = input.nextDouble();
        
        System.out.print("Enter an operator (+, -, *, /): ");
        operator = input.next().charAt(0);
        
        try {
            Operation operation = Factory.getOperation(operator);
            result = operation.execute(num1, num2);
            System.out.println(num1 + " " + operator + " " + num2 + " = " + result);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        RunCalculator(args);
    }
}
