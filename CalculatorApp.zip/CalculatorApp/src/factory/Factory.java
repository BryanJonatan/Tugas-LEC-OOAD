package factory;

import command.Addition;
import command.Division;
import command.Multiplication;
import command.Operation;
import command.Subtraction;

public class Factory {
 public static Operation getOperation(char operator) {
     switch (operator) {
         case '+':
             return new Addition();
         case '-':
             return new Subtraction();
         case '*':
             return new Multiplication();
         case '/':
             return new Division();
         default:
             throw new IllegalArgumentException("Invalid operator: " + operator);
     }
 }
}

