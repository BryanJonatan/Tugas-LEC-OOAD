package command;

public interface Operation {
	double execute(double num1, double num2);
}
